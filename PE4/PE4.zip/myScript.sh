echo "what is your name?"
read name
echo "How do you do, $name?"
read remark